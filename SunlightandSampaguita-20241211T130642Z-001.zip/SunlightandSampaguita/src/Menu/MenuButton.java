package Menu;

import javax.swing.JFrame;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JOptionPane;
import javax.swing.Box;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuButton {
	public void menubutton() {
	JFrame frame = new JFrame("Game Menu");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(1000, 750);
    frame.setLayout(new BorderLayout());

    JPanel buttonPanel = new JPanel();
    buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
    
    buttonPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

    JButton startGameButton = new JButton("Start Game");
    JButton loadGameButton = new JButton("Load Game");
    JButton settingsButton = new JButton("Settings");
    JButton exitButton = new JButton("Exit");
    
    Dimension buttonSize = new Dimension(200, 80);
    startGameButton.setMaximumSize(buttonSize);
    loadGameButton.setMaximumSize(buttonSize);
    settingsButton.setMaximumSize(buttonSize);
    exitButton.setMaximumSize(buttonSize);
    

    buttonPanel.add(startGameButton);
    buttonPanel.add(Box.createRigidArea(new Dimension(0, 40)));
    buttonPanel.add(loadGameButton);
    buttonPanel.add(Box.createRigidArea(new Dimension(0, 40)));
    buttonPanel.add(settingsButton);
    buttonPanel.add(Box.createRigidArea(new Dimension(0, 40)));
    buttonPanel.add(exitButton);

    
    startGameButton.setAlignmentX(Component.CENTER_ALIGNMENT);
    loadGameButton.setAlignmentX(Component.CENTER_ALIGNMENT);
    settingsButton.setAlignmentX(Component.CENTER_ALIGNMENT);
    exitButton.setAlignmentX(Component.CENTER_ALIGNMENT);
    
    
    startGameButton.addActionListener(e->JOptionPane.showMessageDialog(frame, "Startou Gamu da"));
    loadGameButton.addActionListener(e->JOptionPane.showMessageDialog(frame, "Startou Gamu da"));
    settingsButton.addActionListener(e->JOptionPane.showMessageDialog(frame, "Startou Gamu da"));
    exitButton.addActionListener(e->{
    	int respond = JOptionPane.showConfirmDialog(frame, "Are you sure ;)", "Confirm Exit", JOptionPane.YES_NO_OPTION);
    	if(respond == JOptionPane.YES_OPTION) {
    		frame.dispose();
    	}
    });

    buttonPanel.add(startGameButton);
    buttonPanel.add(loadGameButton);
    buttonPanel.add(settingsButton);
    buttonPanel.add(exitButton);


    frame.add(buttonPanel, BorderLayout.CENTER);

    frame.setLocationRelativeTo(null);
    frame.setVisible(true);
	}
}
