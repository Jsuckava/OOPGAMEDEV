package Menu;

public class Main {

	public static void main(String[] args) {
		MenuButton menu = new MenuButton();
		
		menu.menubutton();
	}

}
